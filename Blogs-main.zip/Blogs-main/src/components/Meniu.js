import food from '../images/food.jpg';


const Meniu = () => {
    return (
      <div className="meniu">
      
        <img src={food} alt="food"></img>

      </div>
    )


  


}  
  
  export default Meniu;


  